PEDRO HENRIQUE IZIDORO PEREIRA - 324238576
Mateus de Oliveira Barbosa - 324222461
Yan Gilson de Castro Ramos - 324229414
Davi Henrique do Carmo - 324238198
Luis Filipe Silva Gonçalves - 324220086
Gabriel Moraes Soares de Oliveira  -324268012
